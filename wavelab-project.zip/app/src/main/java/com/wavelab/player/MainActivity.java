package com.wavelab.player;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.Settings;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import java.io.OutputStream;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> filePick;
    private PermissionRequest pendingPerm;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(0xFF0E1020);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setGeolocationEnabled(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        web.addJavascriptInterface(new Bridge(), "WL");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("wavelab.local".equals(u.getHost()) && u.getPath() != null) {
                    try {
                        String rg = r.getRequestHeaders().get("Range");
                        if (u.getPath().startsWith("/media/") && hasAudio()) {
                            return serveMedia(u.getLastPathSegment(), rg);
                        }
                        if (u.getPath().equals("/proxy")) {
                            return serveProxy(u.getQueryParameter("u"), rg);
                        }
                        return null;
                    } catch (Exception e) {
                        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
                    }
                }
                return null;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        r.grant(r.getResources());
                    } else {
                        pendingPerm = r;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePick != null) filePick.onReceiveValue(null);
                filePick = cb;
                try {
                    startActivityForResult(p.createIntent(), 2);
                } catch (Exception e) {
                    filePick = null;
                    return false;
                }
                return true;
            }
        });

        web.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 3);
        }
    }

    private String audioPerm() {
        return Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO
                : Manifest.permission.READ_EXTERNAL_STORAGE;
    }

    private boolean hasAudio() {
        return checkSelfPermission(audioPerm()) == PackageManager.PERMISSION_GRANTED;
    }

    private void jsRefresh() {
        runOnUiThread(() -> {
            if (web != null) web.evaluateJavascript("if(window.localRefresh)localRefresh()", null);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        jsRefresh();
    }

    // Streams online audio on behalf of the page and adds the CORS header, so the
    // EQ, reverb and other effects can process it.
    private WebResourceResponse serveProxy(String target, String range) throws Exception {
        URL url = new URL(target);
        if (!"https".equals(url.getProtocol())) throw new IOException("https only");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setInstanceFollowRedirects(true);
        c.setConnectTimeout(10000);
        c.setReadTimeout(20000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) Wavelab/1.0");
        if (range != null) c.setRequestProperty("Range", range);
        int code = c.getResponseCode();
        String mime = c.getContentType();
        mime = mime == null ? "audio/mpeg" : mime.split(";")[0].trim();
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        String v = c.getHeaderField("Content-Range");
        if (v != null) h.put("Content-Range", v);
        v = c.getHeaderField("Content-Length");
        if (v != null) h.put("Content-Length", v);
        v = c.getHeaderField("Accept-Ranges");
        if (v != null) h.put("Accept-Ranges", v);
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        if (in == null) in = new ByteArrayInputStream(new byte[0]);
        String reason = c.getResponseMessage();
        if (reason == null || reason.isEmpty()) reason = code == 206 ? "Partial Content" : "OK";
        return new WebResourceResponse(mime, null, code, reason, h, in);
    }

    private WebResourceResponse serveMedia(String id, String range) throws Exception {
        Uri uri = Uri.withAppendedPath(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
        ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "r");
        long len = pfd.getStatSize();
        long start = 0, end = len - 1;
        boolean partial = false;
        if (range != null && range.startsWith("bytes=")) {
            String[] p = range.substring(6).split("-", 2);
            if (p[0].isEmpty() && p.length > 1 && !p[1].isEmpty()) {
                start = Math.max(0, len - Long.parseLong(p[1]));
            } else {
                if (!p[0].isEmpty()) start = Long.parseLong(p[0]);
                if (p.length > 1 && !p[1].isEmpty()) end = Math.min(len - 1, Long.parseLong(p[1]));
            }
            partial = true;
        }
        if (start > end) {
            start = 0;
            end = len - 1;
            partial = false;
        }
        FileInputStream fis = new FileInputStream(pfd.getFileDescriptor());
        fis.getChannel().position(start);
        long remaining = end - start + 1;
        String mime = getContentResolver().getType(uri);
        if (mime == null) mime = "audio/mpeg";
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Accept-Ranges", "bytes");
        h.put("Content-Length", String.valueOf(remaining));
        if (partial) h.put("Content-Range", "bytes " + start + "-" + end + "/" + len);
        return new WebResourceResponse(mime, null, partial ? 206 : 200,
                partial ? "Partial Content" : "OK", h, new BoundedStream(fis, pfd, remaining));
    }

    private static class BoundedStream extends InputStream {
        private final FileInputStream in;
        private final ParcelFileDescriptor pfd;
        private long left;

        BoundedStream(FileInputStream in, ParcelFileDescriptor pfd, long left) {
            this.in = in;
            this.pfd = pfd;
            this.left = left;
        }

        @Override
        public int read() throws IOException {
            if (left <= 0) return -1;
            int b = in.read();
            if (b >= 0) left--;
            return b;
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int n = in.read(b, off, (int) Math.min(len, left));
            if (n > 0) left -= n;
            return n;
        }

        @Override
        public void close() throws IOException {
            try {
                in.close();
            } finally {
                pfd.close();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 4) {
            boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
            getSharedPreferences("w", 0).edit().putBoolean("den", !ok).apply();
            jsRefresh();
        }
        if (code == 1 && pendingPerm != null) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
                pendingPerm.grant(pendingPerm.getResources());
            } else {
                pendingPerm.deny();
            }
            pendingPerm = null;
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 2 && filePick != null) {
            filePick.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            filePick = null;
        }
    }

    @Override
    public void onBackPressed() {
        // Keep the music playing: send the app to the background instead of closing it.
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        stopService(new Intent(this, PlayerService.class));
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private class Bridge {
        @JavascriptInterface
        public String localState() {
            if (hasAudio()) return "granted";
            return getSharedPreferences("w", 0).getBoolean("den", false) ? "denied" : "ask";
        }

        @JavascriptInterface
        public void ask() {
            runOnUiThread(() -> requestPermissions(new String[]{audioPerm()}, 4));
        }

        @JavascriptInterface
        public void openSettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()))));
        }

        @JavascriptInterface
        public String songs() {
            JSONArray a = new JSONArray();
            if (!hasAudio()) return "[]";
            String sel = android.provider.MediaStore.Audio.Media.IS_RINGTONE + "=0 AND "
                    + android.provider.MediaStore.Audio.Media.IS_NOTIFICATION + "=0 AND "
                    + android.provider.MediaStore.Audio.Media.IS_ALARM + "=0 AND "
                    + android.provider.MediaStore.Audio.Media.DURATION + ">=15000";
            String[] cols = {
                    android.provider.MediaStore.Audio.Media._ID,
                    android.provider.MediaStore.Audio.Media.TITLE,
                    android.provider.MediaStore.Audio.Media.ARTIST,
                    android.provider.MediaStore.Audio.Media.DURATION,
                    android.provider.MediaStore.Audio.Media.DISPLAY_NAME};
            try (Cursor c = getContentResolver().query(
                    android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cols, sel, null,
                    android.provider.MediaStore.Audio.Media.DATE_ADDED + " DESC")) {
                if (c != null) {
                    while (c.moveToNext()) {
                        String title = c.getString(1);
                        String artist = c.getString(2);
                        String name = c.getString(4);
                        if (title == null || title.isEmpty() || title.equals("<unknown>")) {
                            title = name == null ? "Unknown" : name.replaceAll("\\.[^.]+$", "");
                        }
                        if (artist == null || artist.equals("<unknown>")) artist = "";
                        a.put(new JSONObject().put("id", c.getLong(0)).put("t", title)
                                .put("a", artist).put("d", c.getLong(3)));
                    }
                }
            } catch (Exception ignored) {
            }
            return a.toString();
        }

        private OutputStream out;
        private Uri outUri;

        @JavascriptInterface
        public boolean begin(String name, String mime) {
            try {
                if (Build.VERSION.SDK_INT < 29) return false;
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Wavelab");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                outUri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                out = getContentResolver().openOutputStream(outUri);
                return out != null;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean write(String b64) {
            try {
                out.write(Base64.decode(b64, Base64.DEFAULT));
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean end() {
            try {
                out.close();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(outUri, v, null, null);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void state(boolean playing, String title) {
            try {
                Intent i = new Intent(MainActivity.this, PlayerService.class);
                i.putExtra("t", title);
                if (playing) {
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
                    else startService(i);
                } else {
                    stopService(i);
                }
            } catch (Exception ignored) {
            }
        }
    }
}
